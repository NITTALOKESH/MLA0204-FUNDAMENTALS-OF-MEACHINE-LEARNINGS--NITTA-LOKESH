<?php
// Update these settings for your local MySQL installation.
$DB_HOST = "localhost";
$DB_NAME = "used_car_db";
$DB_USER = "root";
$DB_PASS = "";

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    die("Database connection failed. Import database.sql and check config.php. Details: " . htmlspecialchars($e->getMessage()));
}
if (session_status() === PHP_SESSION_NONE) session_start();

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function logged_in() { return !empty($_SESSION['user']); }
function role_is($role) { return logged_in() && $_SESSION['user']['role'] === $role; }
function require_login() {
    if (!logged_in()) { header("Location: index.php?page=login"); exit; }
}
function flash($msg) { $_SESSION['flash'] = $msg; }
function show_flash() {
    if (!empty($_SESSION['flash'])) {
        echo '<div class="flash">'.h($_SESSION['flash']).'</div>';
        unset($_SESSION['flash']);
    }
}
function current_user_id() { return $_SESSION['user']['id'] ?? 0; }
