<?php
require_once "config.php";
$page = $_GET['page'] ?? 'home';
$allowed = ['home','login','register','logout','car','add_car','edit_car','bookings','maintenance','add_service','admin','favourites','my_bookings','compare'];
if (!in_array($page, $allowed, true)) $page = 'home';

if ($page === 'logout') { session_destroy(); header("Location: index.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'register') {
        $name=trim($_POST['name']??''); $email=trim($_POST['email']??'');
        $pass=$_POST['password']??''; $role=$_POST['role']??'customer';
        if (!in_array($role,['customer','seller'],true)) $role='customer';
        if ($name && filter_var($email,FILTER_VALIDATE_EMAIL) && strlen($pass)>=6) {
            try {
                $st=$pdo->prepare("INSERT INTO users(name,email,password,role,phone) VALUES(?,?,?,?,?)");
                $st->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT),$role,trim($_POST['phone']??'')]);
                flash("Account created. Please log in."); header("Location: index.php?page=login"); exit;
            } catch(PDOException $e) { flash("That email is already registered."); }
        } else flash("Enter valid details. Password must contain at least 6 characters.");
        header("Location: index.php?page=register"); exit;
    }
    if ($action === 'login') {
        $st=$pdo->prepare("SELECT * FROM users WHERE email=?"); $st->execute([trim($_POST['email']??'')]); $u=$st->fetch();
        if ($u && password_verify($_POST['password']??'', $u['password'])) {
            $_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];
            header("Location: index.php"); exit;
        }
        flash("Incorrect email or password."); header("Location: index.php?page=login"); exit;
    }
    if ($action === 'add_car' || $action === 'edit_car') {
        require_login();
        if (!in_array($_SESSION['user']['role'],['seller','admin'],true)) die("Seller access required.");
        $data=[current_user_id(),trim($_POST['title']),trim($_POST['brand']),trim($_POST['model']),
          (int)$_POST['year'],(float)$_POST['price'],(int)$_POST['mileage'],trim($_POST['fuel']),
          trim($_POST['transmission']),(int)$_POST['owners'],trim($_POST['condition_text']),
          trim($_POST['description']),trim($_POST['image_url']),trim($_POST['city'])];
        if ($action==='add_car') {
            $st=$pdo->prepare("INSERT INTO cars(seller_id,title,brand,model,year,price,mileage,fuel,transmission,owners,condition_text,description,image_url,city) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $st->execute($data); flash("Car listing added successfully.");
        } else {
            $id=(int)$_POST['id'];
            $st=$pdo->prepare("UPDATE cars SET title=?,brand=?,model=?,year=?,price=?,mileage=?,fuel=?,transmission=?,owners=?,condition_text=?,description=?,image_url=?,city=? WHERE id=? AND (seller_id=? OR ?='admin')");
            $params=array_slice($data,1); $params[]=$id; $params[]=current_user_id(); $params[]=$_SESSION['user']['role'];
            $st=$pdo->prepare("UPDATE cars SET title=?,brand=?,model=?,year=?,price=?,mileage=?,fuel=?,transmission=?,owners=?,condition_text=?,description=?,image_url=?,city=? WHERE id=? AND (seller_id=? OR ?='admin')");
            $st->execute(array_merge($params));
            flash("Car listing updated.");
        }
        header("Location: index.php"); exit;
    }
    if ($action === 'book') {
        require_login(); $car=(int)$_POST['car_id'];
        $st=$pdo->prepare("SELECT status FROM cars WHERE id=?"); $st->execute([$car]); $c=$st->fetch();
        if ($c && $c['status']==='Available') {
            $st=$pdo->prepare("INSERT INTO bookings(car_id,customer_id,message) VALUES(?,?,?)");
            $st->execute([$car,current_user_id(),trim($_POST['message']??'')]);
            flash("Booking request sent. You can track it in My Bookings.");
        } else flash("This car is not currently available.");
        header("Location: index.php?page=car&id=".$car); exit;
    }
    if ($action === 'booking_status') {
        require_login();
        if (!in_array($_SESSION['user']['role'],['seller','admin'],true)) die("Access denied.");
        $id=(int)$_POST['booking_id']; $status=$_POST['status']??'Pending';
        if (!in_array($status,['Confirmed','Rejected'],true)) $status='Pending';
        $pdo->beginTransaction();
        $st=$pdo->prepare("SELECT b.car_id FROM bookings b JOIN cars c ON c.id=b.car_id WHERE b.id=? AND (c.seller_id=? OR ?='admin') FOR UPDATE");
        $st->execute([$id,current_user_id(),$_SESSION['user']['role']]); $b=$st->fetch();
        if ($b) {
            $pdo->prepare("UPDATE bookings SET status=? WHERE id=?")->execute([$status,$id]);
            if ($status==='Confirmed') $pdo->prepare("UPDATE cars SET status='Booked' WHERE id=?")->execute([$b['car_id']]);
            if ($status==='Rejected') $pdo->prepare("UPDATE cars SET status='Available' WHERE id=? AND status='Booked'")->execute([$b['car_id']]);
        }
        $pdo->commit(); flash("Booking status updated."); header("Location: index.php?page=bookings"); exit;
    }
    if ($action === 'add_service') {
        require_login(); $car=(int)$_POST['car_id'];
        $st=$pdo->prepare("SELECT id FROM cars WHERE id=? AND (seller_id=? OR ?='admin')");
        $st->execute([$car,current_user_id(),$_SESSION['user']['role']]); 
        if ($st->fetch()) {
            $st=$pdo->prepare("INSERT INTO maintenance(car_id,service_date,service_type,details,cost,next_service) VALUES(?,?,?,?,?,?)");
            $st->execute([$car,$_POST['service_date'],trim($_POST['service_type']),trim($_POST['details']),(float)$_POST['cost'],$_POST['next_service']?:null]);
            flash("Service record saved.");
        } else flash("You cannot add a service record for this car.");
        header("Location: index.php?page=maintenance&car_id=".$car); exit;
    }
    if ($action === 'favourite') {
        require_login(); $car=(int)$_POST['car_id'];
        $st=$pdo->prepare("SELECT 1 FROM favourites WHERE user_id=? AND car_id=?"); $st->execute([current_user_id(),$car]);
        if ($st->fetch()) $pdo->prepare("DELETE FROM favourites WHERE user_id=? AND car_id=?")->execute([current_user_id(),$car]);
        else $pdo->prepare("INSERT IGNORE INTO favourites(user_id,car_id) VALUES(?,?)")->execute([current_user_id(),$car]);
        header("Location: ".($_POST['return_to']??'index.php')); exit;
    }
}

function car_card($c) {
    $img=$c['image_url'] ?: 'https://placehold.co/800x500?text=Used+Car';
    echo '<article class="car-card"><a href="index.php?page=car&id='.(int)$c['id'].'"><img src="'.h($img).'" alt="'.h($c['title']).'" onerror="this.src=\'https://placehold.co/800x500?text=Car\'"></a><div class="car-body"><div class="row"><span class="tag">'.h($c['year']).'</span><span class="tag">'.h($c['fuel']).'</span><span class="tag">'.h($c['status']).'</span></div><h3><a href="index.php?page=car&id='.(int)$c['id'].'">'.h($c['title']).'</a></h3><p class="muted">'.h($c['mileage']).' km · '.h($c['transmission']).' · '.h($c['city']).'</p><div class="price">₹'.number_format((float)$c['price']).'</div><a class="btn btn-small" href="index.php?page=car&id='.(int)$c['id'].'">View details</a></div></article>';
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>AutoHub | Used Car Marketplace</title><link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"></head><body>
<header class="topbar"><a class="brand" href="index.php">🚘 AutoHub</a><nav><a href="index.php">Home</a><a href="index.php#cars">Browse Cars</a><?php if(logged_in()): ?><a href="index.php?page=my_bookings">My Bookings</a><?php if(in_array($_SESSION['user']['role'],['seller','admin'])): ?><a href="index.php?page=add_car">Sell a Car</a><a href="index.php?page=bookings">Manage Bookings</a><a href="index.php?page=maintenance">Service Records</a><?php endif; ?><?php if(role_is('admin')): ?><a href="index.php?page=admin">Admin</a><?php endif; ?><span class="nav-user">Hi, <?=h($_SESSION['user']['name'])?></span><a href="index.php?page=logout">Logout</a><?php else: ?><a href="index.php?page=login">Login</a><a class="nav-cta" href="index.php?page=register">Get Started</a><?php endif; ?></nav></header>
<main class="container"><?php show_flash(); ?>
<?php if($page==='home'):
    $where=["c.status='Available'"]; $params=[];
    if(!empty($_GET['q'])) { $where[]="(c.title LIKE ? OR c.brand LIKE ? OR c.model LIKE ?)"; $q='%'.$_GET['q'].'%'; array_push($params,$q,$q,$q); }
    if(!empty($_GET['brand'])) { $where[]="c.brand=?"; $params[]=$_GET['brand']; }
    if(!empty($_GET['max_price'])) { $where[]="c.price<=?"; $params[]=(float)$_GET['max_price']; }
    $sql="SELECT c.* FROM cars c WHERE ".implode(" AND ",$where)." ORDER BY c.created_at DESC";
    $st=$pdo->prepare($sql); $st->execute($params); $cars=$st->fetchAll();
?>
<section class="hero"><div><span class="eyebrow">TRUSTED PRE-OWNED CAR MARKETPLACE</span><h1>Find your next car.<br><em>Drive with confidence.</em></h1><p>Discover verified listings, compare vehicles, request bookings and explore service history — all in one place.</p><a class="btn" href="#cars">Explore Cars</a> <a class="btn btn-outline" href="index.php?page=register">Join AutoHub</a></div><div class="hero-art"><div class="hero-circle"></div><img src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1200&q=85" alt="Premium used car"></div></section>
<section class="stats"><div><strong><?=count($cars)?></strong><span>Available demo cars</span></div><div><strong>3</strong><span>User roles</span></div><div><strong>24/7</strong><span>Online access</span></div><div><strong>360°</strong><span>Vehicle information</span></div></section>
<section id="cars" class="section"><div class="section-head"><div><span class="eyebrow">DISCOVER YOUR MATCH</span><h2>Explore used cars</h2></div><span class="muted"><?=count($cars)?> cars found</span></div>
<form class="searchbar" method="get"><input type="hidden" name="page" value="home"><input name="q" placeholder="Search brand, model or car..." value="<?=h($_GET['q']??'')?>"><select name="brand"><option value="">All brands</option><?php foreach(['Hyundai','Maruti Suzuki','Honda','Tata','Toyota','Mahindra','Kia'] as $b): ?><option <?=($_GET['brand']??'')===$b?'selected':''?>><?=h($b)?></option><?php endforeach; ?></select><input type="number" name="max_price" placeholder="Max budget (₹)" value="<?=h($_GET['max_price']??'')?>"><button class="btn">Search</button></form>
<div class="car-grid"><?php if($cars): foreach($cars as $c) car_card($c); else: ?><p>No cars found. Try changing your filters.</p><?php endif; ?></div></section>
<section class="section feature-band"><div><span class="eyebrow">SMART BUYING TOOLS</span><h2>More than just a car listing.</h2><p>Compare cars, estimate EMI, calculate a fair price and locate nearby vehicles.</p></div><div class="feature-grid"><div>📍<b>Live location</b><small>Find cars around you</small></div><div>⚖️<b>Compare</b><small>Choose with confidence</small></div><div>🧮<b>EMI calculator</b><small>Plan your budget</small></div><div>🛡️<b>Health score</b><small>Check vehicle condition</small></div></div></section>
<section class="section"><div class="section-head"><div><span class="eyebrow">LOCATION DISCOVERY</span><h2>Find cars near you</h2><p class="muted">Share your location to view nearby listings. Your browser will ask for permission.</p></div><button class="btn" onclick="locateMe()">Use my live location</button></div><div id="map" class="map"></div><p id="locationStatus" class="muted">Location is off until you choose to share it.</p></section>
<?php elseif($page==='login' || $page==='register'): ?>
<div class="auth-wrap"><div class="auth-info"><span class="eyebrow">WELCOME TO AUTOHUB</span><h1>Your next journey starts here.</h1><p>Buy, sell and manage pre-owned vehicles with transparent information and easy booking.</p><div class="auth-points">✓ Role-based accounts<br>✓ Service history<br>✓ Smart comparison tools</div></div><form class="auth-card" method="post"><h2><?=$page==='login'?'Login to your account':'Create your account'?></h2><input type="hidden" name="action" value="<?=$page==='login'?'login':'register'?>"><?php if($page==='register'): ?><label>Full name</label><input name="name" required><label>Phone</label><input name="phone"><label>Account type</label><select name="role"><option value="customer">Customer</option><option value="seller">Seller</option></select><?php endif; ?><label>Email address</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required minlength="6"><button class="btn full"><?=$page==='login'?'Login':'Create account'?></button><p class="muted"><?=$page==='login'?'New to AutoHub? <a href="index.php?page=register">Register here</a>':'Already registered? <a href="index.php?page=login">Login</a>'?></p></form></div>
<?php elseif($page==='car'):
    $id=(int)($_GET['id']??0); $st=$pdo->prepare("SELECT c.*,u.name seller_name FROM cars c JOIN users u ON u.id=c.seller_id WHERE c.id=?"); $st->execute([$id]); $c=$st->fetch();
    if(!$c) echo '<h2>Car not found</h2>'; else:
    $st=$pdo->prepare("SELECT * FROM maintenance WHERE car_id=? ORDER BY service_date DESC"); $st->execute([$id]); $services=$st->fetchAll();
    $fav=false; if(logged_in()) { $st=$pdo->prepare("SELECT 1 FROM favourites WHERE user_id=? AND car_id=?"); $st->execute([current_user_id(),$id]); $fav=(bool)$st->fetch(); }
?>
<div class="detail-layout"><div><img class="detail-image" src="<?=h($c['image_url'])?>" alt="<?=h($c['title'])?>"><div class="panel"><h2>Vehicle overview</h2><p><?=h($c['description'])?></p><div class="spec-grid"><?php foreach(['Brand'=>'brand','Model'=>'model','Year'=>'year','Mileage'=>'mileage','Fuel'=>'fuel','Transmission'=>'transmission','Owners'=>'owners','Condition'=>'condition_text','City'=>'city'] as $label=>$key): ?><div><small><?=h($label)?></small><b><?=h($c[$key])?><?=$key==='mileage'?' km':''?></b></div><?php endforeach; ?></div></div><div class="panel"><h2>Maintenance & service history</h2><?php if(!$services): ?><p class="muted">No service records have been added yet.</p><?php else: foreach($services as $s): ?><div class="service-row"><b><?=h($s['service_type'])?></b><span><?=h($s['service_date'])?> · ₹<?=number_format((float)$s['cost'])?></span><p><?=h($s['details'])?></p></div><?php endforeach; endif; ?></div></div>
<aside class="panel sticky"><span class="tag"><?=h($c['status'])?></span><h1><?=h($c['title'])?></h1><div class="price big">₹<?=number_format((float)$c['price'])?></div><p class="muted">Seller: <?=h($c['seller_name'])?></p><button class="btn full" onclick="addCompare(<?= (int)$c['id'] ?>,<?=json_encode($c['title'])?>)">＋ Add to compare</button><button class="btn btn-outline full" onclick="estimateEMI(<?= (float)$c['price'] ?>)">Calculate EMI</button><div id="emiResult" class="muted"></div><?php if(logged_in()): ?><form method="post" class="inline-form"><input type="hidden" name="action" value="favourite"><input type="hidden" name="car_id" value="<?=$id?>"><input type="hidden" name="return_to" value="index.php?page=car&id=<?=$id?>"><button class="btn btn-outline full"><?= $fav?'♥ Saved to wishlist':'♡ Add to wishlist' ?></button></form><?php if(role_is('customer')): ?><form method="post"><input type="hidden" name="action" value="book"><input type="hidden" name="car_id" value="<?=$id?>"><label>Message to seller</label><textarea name="message" placeholder="I am interested in this car..."></textarea><button class="btn full" <?=$c['status']!=='Available'?'disabled':''?>>Request booking</button></form><?php endif; ?><?php else: ?><a class="btn full" href="index.php?page=login">Login to book this car</a><?php endif; ?><div class="health"><b>Vehicle health score</b><div class="score"><span style="width:<?=h($c['condition_text']==='Excellent'?92:($c['condition_text']==='Good'?78:55))?>%"></span></div><small>Indicative score based on seller-entered condition. Not a certified inspection.</small></div></aside></div>
<?php endif; ?>
<?php elseif($page==='add_car' || $page==='edit_car'):
    require_login(); if(!in_array($_SESSION['user']['role'],['seller','admin'],true)) die("Seller access required.");
    $c=['id'=>'','title'=>'','brand'=>'','model'=>'','year'=>date('Y'),'price'=>'','mileage'=>'','fuel'=>'Petrol','transmission'=>'Manual','owners'=>1,'condition_text'=>'Good','description'=>'','image_url'=>'','city'=>''];
    if($page==='edit_car') { $st=$pdo->prepare("SELECT * FROM cars WHERE id=? AND (seller_id=? OR ?='admin')"); $st->execute([(int)$_GET['id'],current_user_id(),$_SESSION['user']['role']]); $c=$st->fetch() ?: $c; }
?>
<div class="form-panel"><span class="eyebrow">SELLER STUDIO</span><h1><?=$page==='edit_car'?'Edit vehicle':'List your car'?></h1><form method="post" class="form-grid"><input type="hidden" name="action" value="<?=$page==='edit_car'?'edit_car':'add_car'?>"><input type="hidden" name="id" value="<?=h($c['id'])?>"><?php foreach(['title'=>'Listing title','brand'=>'Brand','model'=>'Model','year'=>'Manufacturing year','price'=>'Expected price (₹)','mileage'=>'Mileage (km)','fuel'=>'Fuel type','transmission'=>'Transmission','owners'=>'Number of owners','condition_text'=>'Condition','city'=>'City','image_url'=>'Car image URL'] as $key=>$label): ?><label><?=h($label)?><?php if(in_array($key,['fuel','transmission','condition_text'])): ?><select name="<?=$key?>"><?php foreach(($key==='fuel'?['Petrol','Diesel','CNG','Electric','Hybrid']:($key==='transmission'?['Manual','Automatic']:['Excellent','Good','Fair'])) as $v): ?><option <?=($c[$key]??'')===$v?'selected':''?>><?=$v?></option><?php endforeach; ?></select><?php else: ?><input name="<?=$key?>" value="<?=h($c[$key]??'')?>" <?=in_array($key,['title','brand','model','year','price','mileage'])?'required':''?>></label><?php endif; ?></label><?php endforeach; ?><label class="wide">Description<textarea name="description"><?=h($c['description'])?></textarea></label><button class="btn wide">Save car listing</button></form></div>
<?php elseif($page==='my_bookings' || $page==='bookings'):
    require_login();
    if($page==='bookings' && !in_array($_SESSION['user']['role'],['seller','admin'],true)) die("Seller access required.");
    if($page==='my_bookings') { $st=$pdo->prepare("SELECT b.*,c.title,c.price,c.image_url FROM bookings b JOIN cars c ON c.id=b.car_id WHERE b.customer_id=? ORDER BY b.created_at DESC"); $st->execute([current_user_id()]); }
    else { $st=$pdo->prepare("SELECT b.*,c.title,c.price,u.name customer_name FROM bookings b JOIN cars c ON c.id=b.car_id JOIN users u ON u.id=b.customer_id WHERE c.seller_id=? OR ?='admin' ORDER BY b.created_at DESC"); $st->execute([current_user_id(),$_SESSION['user']['role']]); }
    $rows=$st->fetchAll();
?>
<div class="section-head"><div><span class="eyebrow">BOOKING WORKFLOW</span><h1><?=$page==='my_bookings'?'My booking requests':'Manage booking requests'?></h1></div></div><div class="panel table-wrap"><table><tr><th>Car</th><th><?= $page==='my_bookings'?'Price':'Customer' ?></th><th>Date</th><th>Status</th><?php if($page==='bookings'): ?><th>Action</th><?php endif; ?></tr><?php foreach($rows as $r): ?><tr><td><?=h($r['title'])?></td><td><?= $page==='my_bookings'?'₹'.number_format((float)$r['price']):h($r['customer_name']) ?></td><td><?=h($r['created_at'])?></td><td><span class="status"><?=h($r['status'])?></span></td><?php if($page==='bookings'): ?><td><form method="post" class="row-form"><input type="hidden" name="action" value="booking_status"><input type="hidden" name="booking_id" value="<?=$r['id']?>"><select name="status"><option>Confirmed</option><option>Rejected</option></select><button class="btn btn-small">Update</button></form></td><?php endif; ?></tr><?php endforeach; ?><?php if(!$rows): ?><tr><td colspan="5">No booking records yet.</td></tr><?php endif; ?></table></div>
<?php elseif($page==='maintenance'):
    require_login(); if(!in_array($_SESSION['user']['role'],['seller','admin'],true)) die("Seller access required.");
    $st=$pdo->prepare("SELECT * FROM cars WHERE seller_id=? OR ?='admin' ORDER BY title"); $st->execute([current_user_id(),$_SESSION['user']['role']]); $owned=$st->fetchAll();
    $carid=(int)($_GET['car_id']??($owned[0]['id']??0));
    $st=$pdo->prepare("SELECT m.*,c.title FROM maintenance m JOIN cars c ON c.id=m.car_id WHERE m.car_id=? AND (c.seller_id=? OR ?='admin') ORDER BY service_date DESC"); $st->execute([$carid,current_user_id(),$_SESSION['user']['role']]); $services=$st->fetchAll();
?>
<div class="section-head"><div><span class="eyebrow">VEHICLE CARE</span><h1>Maintenance records</h1></div></div><div class="two-col"><form class="panel" method="post"><h2>Add service record</h2><input type="hidden" name="action" value="add_service"><label>Select car</label><select name="car_id"><?php foreach($owned as $v): ?><option value="<?=$v['id']?>" <?=$carid===$v['id']?'selected':''?>><?=h($v['title'])?></option><?php endforeach; ?></select><label>Service date</label><input type="date" name="service_date" required><label>Service type</label><input name="service_type" placeholder="Oil change / General service" required><label>Details</label><textarea name="details"></textarea><label>Cost (₹)</label><input type="number" name="cost" min="0" step="0.01"><label>Next service date</label><input type="date" name="next_service"><button class="btn full">Save service record</button></form><div class="panel"><h2>Service history</h2><?php foreach($services as $s): ?><div class="service-row"><b><?=h($s['service_type'])?></b><span><?=h($s['service_date'])?> · ₹<?=number_format((float)$s['cost'])?></span><p><?=h($s['details'])?></p><small>Next service: <?=h($s['next_service']??'Not specified')?></small></div><?php endforeach; ?><?php if(!$services): ?><p class="muted">No service records for this car.</p><?php endif; ?></div></div>
<?php elseif($page==='compare'):
    $ids=array_values(array_filter(array_map('intval', explode(',', $_GET['ids']??''))));
    $ids=array_slice(array_unique($ids),0,3);
    $cars=[];
    if($ids){ $marks=implode(',',array_fill(0,count($ids),'?')); $st=$pdo->prepare("SELECT * FROM cars WHERE id IN ($marks)"); $st->execute($ids); $cars=$st->fetchAll(); }
?>
<div class="section-head"><div><span class="eyebrow">SMART BUYING TOOL</span><h1>Compare selected cars</h1><p class="muted">Compare key details before you decide.</p></div></div>
<div id="compareEmpty" class="panel" style="display:none">Select at least one car from a vehicle details page to compare.</div>
<div class="panel table-wrap"><table><tr><th>Specification</th><?php foreach($cars as $v): ?><th><?=h($v['title'])?></th><?php endforeach; ?></tr>
<?php foreach(['Price'=>'price','Brand'=>'brand','Model'=>'model','Year'=>'year','Mileage (km)'=>'mileage','Fuel'=>'fuel','Transmission'=>'transmission','Owners'=>'owners','Condition'=>'condition_text','City'=>'city'] as $label=>$key): ?><tr><th><?=h($label)?></th><?php foreach($cars as $v): ?><td><?= $key==='price'?'₹'.number_format((float)$v[$key]):h($v[$key]) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
<tr><th>Open listing</th><?php foreach($cars as $v): ?><td><a class="btn btn-small" href="index.php?page=car&id=<?=$v['id']?>">View car</a></td><?php endforeach; ?></tr></table></div>
<p class="muted">Comparison uses listing information entered by sellers. Verify details and inspect the vehicle before purchase.</p>
<?php if(!$cars): ?><script>document.getElementById('compareEmpty').style.display='block';</script><?php endif; ?>
<?php elseif($page==='admin'):
    require_login(); if(!role_is('admin')) die("Admin access required.");
    $users=$pdo->query("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC")->fetchAll();
    $cars=$pdo->query("SELECT c.*,u.name seller_name FROM cars c JOIN users u ON u.id=c.seller_id ORDER BY c.id DESC")->fetchAll();
    $counts=$pdo->query("SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM cars) cars,(SELECT COUNT(*) FROM bookings) bookings")->fetch();
?>
<span class="eyebrow">CONTROL CENTRE</span><h1>Administrator dashboard</h1><div class="stats"><div><strong><?=$counts['users']?></strong><span>Users</span></div><div><strong><?=$counts['cars']?></strong><span>Car listings</span></div><div><strong><?=$counts['bookings']?></strong><span>Bookings</span></div></div><div class="panel table-wrap"><h2>All vehicle listings</h2><table><tr><th>Vehicle</th><th>Seller</th><th>Price</th><th>Status</th><th>Action</th></tr><?php foreach($cars as $v): ?><tr><td><?=h($v['title'])?></td><td><?=h($v['seller_name'])?></td><td>₹<?=number_format((float)$v['price'])?></td><td><?=h($v['status'])?></td><td><a href="index.php?page=edit_car&id=<?=$v['id']?>">Edit</a></td></tr><?php endforeach; ?></table></div><div class="panel table-wrap"><h2>Registered users</h2><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr><?php foreach($users as $u): ?><tr><td><?=h($u['name'])?></td><td><?=h($u['email'])?></td><td><?=h($u['role'])?></td><td><?=h($u['created_at'])?></td></tr><?php endforeach; ?></table></div>
<?php endif; ?>
</main><footer><b>🚘 AutoHub</b><span>Online Used Car Sales and Management System · Academic project prototype</span><span>Built with HTML, CSS, JavaScript, PHP & MySQL</span></footer>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script src="assets/app.js"></script>
</body></html>