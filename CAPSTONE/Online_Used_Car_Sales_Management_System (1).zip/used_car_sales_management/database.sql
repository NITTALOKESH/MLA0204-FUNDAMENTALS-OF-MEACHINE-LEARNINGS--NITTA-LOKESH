CREATE DATABASE IF NOT EXISTS used_car_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE used_car_db;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('customer','seller','admin') NOT NULL DEFAULT 'customer',
 phone VARCHAR(25) DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cars (
 id INT AUTO_INCREMENT PRIMARY KEY,
 seller_id INT NOT NULL,
 title VARCHAR(160) NOT NULL,
 brand VARCHAR(70) NOT NULL,
 model VARCHAR(70) NOT NULL,
 year INT NOT NULL,
 price DECIMAL(12,2) NOT NULL,
 mileage INT NOT NULL,
 fuel VARCHAR(30) NOT NULL,
 transmission VARCHAR(30) NOT NULL,
 owners INT DEFAULT 1,
 condition_text VARCHAR(30) DEFAULT 'Good',
 description TEXT,
 image_url TEXT,
 city VARCHAR(100) DEFAULT '',
 latitude DECIMAL(10,7) DEFAULT NULL,
 longitude DECIMAL(10,7) DEFAULT NULL,
 status ENUM('Available','Booked','Sold','Pending Approval') DEFAULT 'Available',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS bookings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 car_id INT NOT NULL,
 customer_id INT NOT NULL,
 message TEXT,
 status ENUM('Pending','Confirmed','Rejected','Cancelled') DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE,
 FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS maintenance (
 id INT AUTO_INCREMENT PRIMARY KEY,
 car_id INT NOT NULL,
 service_date DATE NOT NULL,
 service_type VARCHAR(120) NOT NULL,
 details TEXT,
 cost DECIMAL(10,2) DEFAULT 0,
 next_service DATE DEFAULT NULL,
 FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS favourites (
 user_id INT NOT NULL,
 car_id INT NOT NULL,
 PRIMARY KEY(user_id, car_id),
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

-- Demo accounts (password for all three is password)
INSERT IGNORE INTO users(name,email,password,role,phone) VALUES
('Demo Admin','admin@usedcar.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin','9000000001'),
('Demo Seller','seller@usedcar.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','seller','9000000002'),
('Demo Customer','customer@usedcar.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','customer','9000000003');

INSERT INTO cars(seller_id,title,brand,model,year,price,mileage,fuel,transmission,owners,condition_text,description,image_url,city,status)
SELECT id,'Hyundai Creta SX','Hyundai','Creta SX',2021,1120000,32000,'Petrol','Automatic',1,'Excellent','Single owner, full service history, reverse camera and alloy wheels.','https://images.unsplash.com/photo-1606152421802-db97b9c7a11b?auto=format&fit=crop&w=1000&q=80','Chennai','Available'
FROM users WHERE email='seller@usedcar.test'
AND NOT EXISTS (SELECT 1 FROM cars WHERE title='Hyundai Creta SX');

INSERT INTO cars(seller_id,title,brand,model,year,price,mileage,fuel,transmission,owners,condition_text,description,image_url,city,status)
SELECT id,'Maruti Suzuki Baleno Zeta','Maruti Suzuki','Baleno Zeta',2020,620000,41000,'Petrol','Manual',1,'Good','Well maintained hatchback with insurance and service records.','https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1000&q=80','Chennai','Available'
FROM users WHERE email='seller@usedcar.test'
AND NOT EXISTS (SELECT 1 FROM cars WHERE title='Maruti Suzuki Baleno Zeta');

INSERT INTO cars(seller_id,title,brand,model,year,price,mileage,fuel,transmission,owners,condition_text,description,image_url,city,status)
SELECT id,'Honda City V CVT','Honda','City V CVT',2019,780000,52000,'Petrol','Automatic',2,'Good','Comfortable sedan. Inspection report available on request.','https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=1000&q=80','Bengaluru','Available'
FROM users WHERE email='seller@usedcar.test'
AND NOT EXISTS (SELECT 1 FROM cars WHERE title='Honda City V CVT');
