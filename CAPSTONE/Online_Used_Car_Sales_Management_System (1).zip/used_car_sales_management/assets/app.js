let compareCars = JSON.parse(localStorage.getItem("autohubCompare") || "[]");

function addCompare(id, title) {
  if (!compareCars.some(x => x.id === id)) compareCars.push({id, title});
  if (compareCars.length > 3) compareCars.shift();
  localStorage.setItem("autohubCompare", JSON.stringify(compareCars));
  const go = confirm("Added: " + title + "\nSelected: " + compareCars.map(x => x.title).join(", ") + "\nOpen comparison page now?");
  if (go) window.location.href = "index.php?page=compare&ids=" + compareCars.map(x => x.id).join(",");
}

function estimateEMI(principal) {
  const annualRate = 9.5, months = 60;
  const r = annualRate / 12 / 100;
  const emi = principal * r * Math.pow(1+r, months) / (Math.pow(1+r, months)-1);
  const box = document.getElementById("emiResult");
  if (box) box.innerHTML = "Estimated EMI: <b>₹" + Math.round(emi).toLocaleString("en-IN") + "/month</b><br><small>Illustrative: 9.5% interest for 5 years. Actual lender terms may differ.</small>";
}

let mapInstance;
function locateMe() {
  const status = document.getElementById("locationStatus");
  if (!navigator.geolocation) { status.textContent = "Geolocation is not supported by this browser."; return; }
  status.textContent = "Requesting location permission…";
  navigator.geolocation.getCurrentPosition(position => {
    const lat = position.coords.latitude, lng = position.coords.longitude;
    status.textContent = "Your current location is shown on the map. Location is used only in this browser demo.";
    if (!mapInstance) {
      mapInstance = L.map("map").setView([lat,lng], 12);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {attribution:"© OpenStreetMap"}).addTo(mapInstance);
    } else mapInstance.setView([lat,lng],12);
    L.marker([lat,lng]).addTo(mapInstance).bindPopup("Your current location").openPopup();
    // Demo listing markers are approximate city-centre pins, not real-time vehicle tracking.
    const demoCars = [{lat:13.0827,lng:80.2707,name:"Demo cars – Chennai"},{lat:12.9716,lng:77.5946,name:"Demo cars – Bengaluru"}];
    demoCars.forEach(c => L.marker([c.lat,c.lng]).addTo(mapInstance).bindPopup(c.name + "<br>Demo listing location"));
  }, error => {
    status.textContent = error.code === 1 ? "Location permission was denied. Enable it in browser settings to use this feature." : "Could not get your location. Try again or check your device location.";
  }, {enableHighAccuracy:true, timeout:10000});
}
if (document.getElementById("map")) {
  mapInstance = L.map("map").setView([20.5937,78.9629], 4);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {attribution:"© OpenStreetMap"}).addTo(mapInstance);
}
