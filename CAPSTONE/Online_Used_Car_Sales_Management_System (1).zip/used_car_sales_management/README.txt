AUTOHUB — ONLINE USED CAR SALES AND MANAGEMENT SYSTEM
=====================================================

TECHNOLOGY
- Frontend: HTML5, CSS3, JavaScript
- Backend: PHP 8+
- Database: MySQL / MariaDB
- Map: Leaflet + OpenStreetMap
- Browser location: HTML5 Geolocation API

FEATURES FROM THE PPT
1. Customer, seller and administrator roles
2. Registration and login
3. Car listing, search and filters (brand, keyword, maximum price)
4. Vehicle specifications and availability
5. Booking request with Pending / Confirmed / Rejected status
6. Seller booking management
7. Maintenance/service records and costs
8. Administrator dashboard and user/listing overview

ADDITIONAL PRESENTATION FEATURES
1. Live user location (only after browser permission)
2. Map view with demo listing pins
3. Wishlist / favourite cars
4. EMI estimate calculator
5. Indicative vehicle health score
6. Compare-list selection (browser local storage)
7. Responsive mobile-friendly layout
8. Document verification status can be added as a next development module.

IMPORTANT LIMITATIONS
- The map's Chennai and Bengaluru vehicle pins are demo locations, not actual GPS tracking of cars.
- The vehicle health score is an indicative score based on seller-entered condition, not a certified inspection.
- EMI is an estimate, not a loan offer.
- Online payments, SMS/email alerts, AI valuation, OCR document verification and live vehicle tracking require external services/APIs and are not falsely represented as fully integrated.
- Use HTTPS or localhost for browser geolocation. Browsers generally block location on ordinary insecure HTTP pages.
- This is an academic prototype. Add CSRF protection, stricter validation, audit logs, image upload scanning, rate limiting and production security review before real deployment.

INSTALLATION (XAMPP)
1. Install XAMPP and start Apache + MySQL.
2. Extract the folder "used_car_sales_management" into:
   C:\xampp\htdocs\
3. Open phpMyAdmin:
   http://localhost/phpmyadmin
4. Import database.sql (it creates used_car_db).
5. Open config.php and set your MySQL username/password.
6. Open:
   http://localhost/used_car_sales_management/

DEMO LOGIN ACCOUNTS
Admin:
  admin@usedcar.test
  password

Seller:
  seller@usedcar.test
  password

Customer:
  customer@usedcar.test
  password

DEMO FLOW FOR PRESENTATION
1. Login as customer and browse/search cars.
2. Open a car, view specifications and service history.
3. Add it to wishlist and request a booking.
4. Logout and login as seller.
5. Open Manage Bookings and confirm/reject the request.
6. Add a car listing and maintenance record as seller.
7. Login as admin and show dashboard and registered users.
8. Return to home and click "Use my live location" to demonstrate browser GPS permission and map.
9. Open a car and demonstrate EMI estimate, compare selection and health score.

PROJECT STRUCTURE
used_car_sales_management/
  index.php
  config.php
  database.sql
  README.txt
  assets/
    style.css
    app.js
